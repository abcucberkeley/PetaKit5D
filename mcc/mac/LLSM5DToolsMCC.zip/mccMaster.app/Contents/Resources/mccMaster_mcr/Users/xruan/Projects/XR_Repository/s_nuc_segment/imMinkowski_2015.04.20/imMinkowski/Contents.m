% IMMINKOWSKI Geometric measures (Surface, Perimeter, Euler...) in 2D and 3D images
% Version 1.2 09-Nov-2011 .
