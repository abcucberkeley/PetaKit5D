% matlabPyrTools: Image and Multi-scale Pyramid Tools
% Version: 1.4, December-2009.
