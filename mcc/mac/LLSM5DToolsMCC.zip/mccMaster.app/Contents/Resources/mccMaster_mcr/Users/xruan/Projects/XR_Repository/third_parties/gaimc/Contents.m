%=========================================
% Graph Algorithms in Matlab Code (gaimc)
